
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'davidauzaengineer',
  applicationName: 'myapp',
  appUid: 'RHX09qLq4z75yC6myk',
  orgUid: '08061e32-c3e6-4b72-9d21-78ab41d16707',
  deploymentUid: '65a99139-38e1-4877-a209-e16114f3a032',
  serviceName: 'user-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'user-service-dev-createUser', timeout: 6 };

try {
  const userHandler = require('./src/functions/createUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}